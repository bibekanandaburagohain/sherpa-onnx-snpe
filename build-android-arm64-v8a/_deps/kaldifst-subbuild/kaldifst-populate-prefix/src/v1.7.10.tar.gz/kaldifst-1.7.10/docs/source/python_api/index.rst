
Python API reference
====================

.. toctree::
   :maxdepth: 2

   api
