// kaldifst/python/csrc/text-normalizer.h
//
// Copyright (c)  2023  Xiaomi Corporation
#ifndef KALDIFST_PYTHON_CSRC_TEXT_NORMALIZER_H_
#define KALDIFST_PYTHON_CSRC_TEXT_NORMALIZER_H_

#include "kaldifst/python/csrc/kaldifst.h"
namespace kaldifst {

void PybindTextNormalizer(py::module *m);

}

#endif  // KALDIFST_PYTHON_CSRC_TEXT_NORMALIZER_H_
